to use the code
Get API Key:

Obtain an API key from OpenWeatherMap by signing up for a free account.
